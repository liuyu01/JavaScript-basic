/**
 * 编辑器的store
 * https://juejin.cn/post/6844903767414931463
 * https://zhuanlan.zhihu.com/p/646993873
 */
import { types, Instance} from 'mobx-state-tree';

export const EditorStore = types
  .model('EditorStore', {
    preview: types.string,
    type: types.string,
    schema: types.string,
  })
  .views(self => {
    return {
      get getSchema() {
        return self.schema;
      },
      get getType() {
        return self.type;
      },
      get getPreview() {
        return self.preview;
      },
    };
  })
  .actions(self => {
    return {
      setSchema(val:any){
        self.schema = val;
      },
      setType(val:any){
        self.type = val;
      },
      setPreview(val:any){
        self.preview = val;
      },
    };
  });
  export type EditorStoreInstance = Instance<typeof EditorStore>;
