import React, { useState, useEffect } from 'react';
import {Editor} from 'amis-editor';
import {Icon, Drawer} from 'amis-ui';
// import 'amis/lib/themes/default.css';
import 'amis-editor-core/lib/style.css';
// import 'amis-ui/lib/themes/cxd.css'
import './components/style.scss';
import Title from './components/Title';
import {savePageManage} from "@/api/editor"
import { observer } from "mobx-react"
import { useStore } from "@/store/index"

const AMISEditor: React.FC = observer(() => {
  const { EditorStore } = useStore()
  console.log(15, EditorStore)
  const EditorType = {
    EDITOR: 'editor',
    MOBILE: 'mobile',
    FORM: 'form'
  };
  const formSchema = {
    type: 'doc-entity',
    fields: []
  };
  const schemaVal = {
    type: 'page',
    title: 'Simple Form Page',
    regions: ['body'],
    body: [
      {
        type: 'form',
        body: [
          {
            type: 'input-text',
            name: 'a',
            label: 'Text'
          }
        ]
      }
    ]
  };
  const getSchema = (type: string) =>{
    if (type === EditorType.FORM) {
      const schema = localStorage.getItem('editting_schema_form');

      if (schema) {
        return JSON.parse(schema);
      }
      return formSchema;
    }

    const lsSchema = localStorage.getItem('editting_schema');
    if (lsSchema) {
      return JSON.parse(lsSchema);
    }

    return schemaVal;
  }
  
  const [schema,setSchema] = useState(
    localStorage.getItem('editting_schema') !=='undefined' ? JSON.parse(localStorage.getItem('editting_schema')!) : schemaVal)
  const [type,setType] = useState(localStorage.getItem('editting_preview_type')  || EditorType.EDITOR)
  const [preview,setPreview] = useState( localStorage.getItem('editting_preview')? true : false )
  const [historyVisible, setHistoryVisible] = useState(false)
  const handleTypeChange = (editorType: any) => {
    const type = editorType || EditorType.EDITOR;
    localStorage.setItem('editting_preview_type', type);
    setType(type)
    setSchema(getSchema(type))
  };
  const handleChange = (value: any) => {

    if (type === EditorType.FORM) {
      localStorage.setItem('editting_schema_form', JSON.stringify(value));
    } else {
      localStorage.setItem('editting_schema', JSON.stringify(value));
    }
    setSchema(value);
  };
  const onSave = async()=>{
      let url = window.location.href;
      url = decodeURI(url);
      var arr1 = url.split("?");
      var obj: any = {}
      if (arr1.length > 1) {
        var arr2 = arr1[1].split("&");
        for (var i = 0; i < arr2.length; i++) {
          var curArr = arr2[i].split("=");
          obj[curArr[0]] = decodeURIComponent(curArr[1])
        }
      }
      const Id = obj.pageId;
      let params1 = {
        'pageContent' : schema,
        'id': Id,
      }
      let res = await savePageManage(params1)
      console.log(84, res)
      localStorage.setItem('editting_schema', JSON.stringify(schema));
  };
  let childRef: any = null;
  const handleChildEvent = (ref: any) => {
      childRef = ref;
  }
  const isMobile = type === EditorType.MOBILE;
  const undo = () => {
    console.log(94)
    childRef?.undo()
  }

  const redo = () => {
    childRef?.redo()
  }
  const  historyCheck = () => {
    setHistoryVisible(true)
  }
  //编辑还是预览按钮操作
  const handlePreviewChange = (preview: any) => {
    localStorage.setItem('editting_preview', preview ? 'true' : '');

    setPreview(!!preview)
  };
  const togglePreview = () => {
    handlePreviewChange(!preview);
  };

  useEffect(()=>{
    const type =
      localStorage.getItem('editting_preview_type') || EditorType.EDITOR;
    setSchema(getSchema(type))
  },[])

  return (
      <>
      <div className="EditorDemo">
        <div id="headerBar" className="EditorHeader">
          <Title />
          <div className="Editor_view_mode_group_container">
            <div className="Editor_view_mode_group">
              <div
                className={type === EditorType.EDITOR ? `Editor_view_mode_btn is_active`: `Editor_view_mode_btn`}
                onClick={() => {
                  handleTypeChange(EditorType.EDITOR);
                }}
              >
                <Icon icon="pc-preview" title="PC模式" />
              </div>
              <div
                className={type === EditorType.MOBILE ?  'Editor_view_mode_btn is_active' : 'Editor_view_mode_btn'}
                onClick={() => {
                  handleTypeChange(EditorType.MOBILE);
                }}
              >
                <Icon icon="h5-preview" title="移动模式" />
              </div>
            </div>
          </div>
          <div className="Editor_header_actions">
            {!preview && 
              <div className="header_quick_actions">
                <div
                  className="shortcut_icon_btn spacing"
                  editor-tooltip="撤回"
                  tooltip-position="bottom"
                >
                  <Icon icon={childRef?.store.canUndo ? 'withdraw-can' : 'withdraw'} onClick={undo} />
                </div>
                <div
                  className="shortcut_icon_btn spacing"
                  editor-tooltip="还原"
                  tooltip-position="bottom"
                >
                  <Icon icon={childRef?.store.canRedo ? 'restore-can' : 'restore'} onClick={redo} />
                </div>
                <div
                  className="shortcut_icon_btn spacing"
                  editor-tooltip="历史记录"
                  tooltip-position="bottom"
                >
                  <Icon icon="history" onClick={historyCheck} />
                </div>
        
                {/* <ShortcutKey /> */}
              </div>
            }
            <Drawer
              size="sm"
              className="history-drawer"
              overlay={false}
              closeOnOutside
              onHide={() =>setHistoryVisible(false)}
              show={historyVisible}
              position="right"
              width={'290px'}
            >
              <div className='history-drawer-header'>
                历史记录
              </div>
              <div className='history-drawer-list'>
                <div className='history-drawer-left'>
                  <div className='history-date'>2023-06-13 17:59:09</div>
                  <div className='history-name'>coffin</div>
                </div>
                <div className='history-drawer-rigth'>
                  <div className='history-button1'>启用此版本</div>
                  <div className='history-button2'>对比</div>
                </div>
              </div>
            </Drawer>
            <div
              className={preview ?  `header_action_btn primary` : 'header_action_btn'}
              onClick={togglePreview}
            >
              {preview ? '编辑' : '预览'}
            </div>

            {!preview && (
              <div
                className="header_action_btn"
                onClick={onSave}
              >
                保存
              </div>
            )}
          </div>
        </div>
        <div className="EditorInner">
          <Editor
            onChildEvent={handleChildEvent}
            isMobile={isMobile}
            onSave={onSave}
            className="is-fixed"
            theme={'cxd'}
            preview={preview}
            showCustomRenderersPanel={true}
            onChange={handleChange}
            value={schema}
            />
        </div>
      </div>
      </>
  )
})

export default AMISEditor;

