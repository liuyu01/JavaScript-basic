import { store } from '../index'
import { defineStore } from 'pinia'
export const menuEnvVarStore = defineStore('menuEnvVar', {
  state: () => ({
    menuEnvVar: 1,
  }),
  getters: {
    getMenuEnvVar():number{
      return this.menuEnvVar
    },
  },
  actions: {
    setMenuEnvVarAction(val) {
      this.menuEnvVar = val;
    }
  }
})
export const useMenuEnvVarStoreWithOut = () => {
  return menuEnvVarStore(store)
}
