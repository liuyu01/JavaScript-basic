import { store } from '../index'
import { defineStore } from 'pinia'
import { getAccessToken, removeToken } from '@/utils/auth'
import { CACHE_KEY, useCache } from '@/hooks/web/useCache'
import { getInfoApi, loginOutApi } from '@/api/login'
import { useConfigStore } from './config'
import { menuEnvVarStore } from '@/store/modules/menuEnvVar'

const { wsCache } = useCache()
const wsCacheSession = useCache('sessionStorage')

interface UserVO {
  id: number
  avatar: string
  nickname: string
}
interface UserInfoVO {
  permissions: string[]
  roles: string[]
  isSetUser: boolean
  user: UserVO
}

export const useUserStore = defineStore('admin-user', {
  state: (): UserInfoVO => ({
    permissions: [],
    roles: [],
    isSetUser: false,
    user: {
      id: 0,
      avatar: '',
      nickname: ''
    }
  }),
  getters: {
    getPermissions(): string[] {
      return this.permissions
    },
    getRoles(): string[] {
      return this.roles
    },
    getIsSetUser(): boolean {
      return this.isSetUser
    },
    getUser(): UserVO {
      return this.user
    }
  },
  actions: {
    async setUserInfoAction() {
      if (!getAccessToken()) {
        this.resetState()
        return null
      }
      let userInfo = wsCache.get(CACHE_KEY.USER)
      if (!userInfo) {
        //登录进去,如果缓存里有上一次的值，直接保持上一次的结果，否则默认是开发环境
        let menuEnvVarVal = 0
        // if (wsCache.get('menuEnvVar')) {
        //   menuEnvVarVal = wsCache.get('menuEnvVar')
        // } else {
        //   menuEnvVarVal = 1
        // }
        menuEnvVarVal =  menuEnvVarStore().getMenuEnvVar;
        userInfo = await getInfoApi(menuEnvVarVal)
      }
      this.permissions = userInfo.permissions
      this.roles = userInfo.roles
      this.user = userInfo.user
      this.isSetUser = true
      wsCache.set(CACHE_KEY.USER, userInfo)
    },
    async loginOut() {
      await loginOutApi()
      removeToken()
      wsCache.clear()
      wsCacheSession.wsCache.clear()
      this.resetState()
      useConfigStore().resetState()
    },
    resetState() {
      this.permissions = []
      this.roles = []
      this.isSetUser = false
      this.user = {
        id: 0,
        avatar: '',
        nickname: ''
      }
    }
  }
})

export const useUserStoreWithOut = () => {
  return useUserStore(store)
}
