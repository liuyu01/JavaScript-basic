import { defineStore } from 'pinia'
import { store } from '../index'
import { getAccessToken } from '@/utils/auth'
import router from '@/router'
import bus from '@/utils/bus'
import { useTagsViewStore } from '@/store/modules/tagsView'

const io = window.io
const SOCKET_URL = import.meta.env.VITE_SOCKET_URL
export interface ProjectState {
  fullSocket: any
  exceptionDeal: {}
  projectMenu: any[]
}
// let fullSocket = null //全局socket
const SocketioClient = {
  createNew: (url) => {
    const client = {}
    client.socket = io(
      `http://${url}?accessToken=${getAccessToken()}` /*, {'force new connection': true, transports: ['websocket'] }*/
    )
    client.socket.on('connect', () => {
      console.log(client.socket.id) // 'G5p5...'
    })
    client.socket.on('connect', () => {
      console.log('连接成功')
    })
    client.socket.on('connect_error', (error) => {
      console.error('连接错误' + error)
    })
    client.socket.on('connect_timeout', () => {
      console.log('连接超时')
    })
    client.socket.on('error', () => {
      //错误发生无法被其它事件类型处理
      // ...
    })
    client.socket.on('disconnect', () => {
      console.log('关闭连接')
    })
    client.socket.on('reconnect', () => {
      console.log('重新连接')
    })
    client.socket.on('reconnect_error', () => {
      console.log('连接错误')
      // ...
    })
    client.socket.on('reconnect_failed', () => {
      console.log('连接失败')
      // ...
    })
    client.socket.on('ping', () => {
      // console.log("向服务器端发送数据包");
    })
    client.socket.on('pong', () => {
      // console.log("接收服务器数据包");
    })
    // 向服务端发送消息
    client.send = function (event, msg, callback) {
      if (callback) {
        client.socket.emit(event, msg, () => callback)
      } else {
        client.socket.emit(event, msg)
      }
    }
    // 接收服务端消息
    client.receive = function (event, callback) {
      client.socket.on(event, callback)
    }
    //移除事件监听
    client.removeListener = function (event, callback) {
      if (callback) {
        client.socket.off(event, callback)
        console.log('callback事件：' + event + '关闭监听')
      } else {
        client.socket.off(event)
        console.log('event事件：' + event + '关闭监听')
      }
    }
    return client
  }
}
export const useGlobalStore = defineStore({
  id: 'global',
  state: (): ProjectState => ({
    fullSocket: null,
    exceptionDeal: {
      overtime: false, //是否超时，默认否401
      accessRights: true, //是否有访问权限403
      notFound: false, //接口是否找不到404
      otherException: false, //其它异常405
      exceptionMessage: '', //后台返回异常信息
      checkExcuteStatue: '' //检测提交流程等待状态
    }, //异常信息处理
    httpServer: '', //服务端ip
    title: '', //标题
    username: null, //当前的登录用户名
    mode: 'online', //反馈问题模式：在线（online）/离线（offline）
    permission: {
      data: [], //权限列表
      warningMsg: {
        noPermission: '无此权限'
      } //提示信息
    }, //token权限信息
    headerDeal: {
      isAction: false,
      newMessage: false, //是否有最新消息
      gridData: [], //消息集合
      showNotice: false, //反馈弹框
      feedbackDialog: false, //反馈弹框
      feedbackOnlineDialog: false //反馈弹框
    }, //主框架头部信息集合
    regexp: {
      fieldName: '^[a-z][a-z0-9_]{0,31}$', //小写英文字母开头，字母、数字、下划线组成,长度1-32
      fieldNameCheckMsg: '小写英文字母开头，小写字母、数字、下划线组成,长度1-32',
      tableName: '^[a-z][a-z0-9_]{0,24}$', //表名小写英文字母开头，由字母、数字、下划线组成，长度1-32
      tableNameCheckMsg: '小写英文字母开头，小写字母、数字、下划线组成,长度1-25'
      //tableName: "^[a-zA-Z][a-zA-Z0-9_]{0,31}$",//英文字母开头，字母、数字、下划线组成，长度1-32
    }, //正则表达式校验集
    otherState: {
      previewProjectFlow: false, //是否是查看流程状态
      uuid: ''
    }
  }),
  actions: {
    openWebsocket() {
      const url = SOCKET_URL.replaceAll('http://', '')
      // const host = url.split(':')[0]
      // const duan = url.split(':')[1]
      this.fullSocket = SocketioClient.createNew(url)
      this.receiveWSMessage()
      this.receiveActionMessage()
      // console.log(this.fullSocket, 'this.fullSocket')
    },
    receiveWSMessage() {
      this.fullSocket.receive('message', (data) => {
        const response = JSON.parse(data)
        this.headerDeal.gridData.unshift({
          content: response.message,
          status: response.status
        })
        this.headerDeal.newMessage = true
      })
    },
    //ws所有返回消息在该方法中接收处理
    receiveActionMessage() {
      //接收action类型消息
      this.fullSocket.receive('action', async (data) => {
        const resMsg = JSON.parse(data)
        const currentRoute = router.currentRoute.value
        switch (resMsg.type) {
          case 'reload':
            if (currentRoute.path == resMsg.target) {
              useTagsViewStore().delCachedView()
              await nextTick()
              router.replace({
                path: '/redirect' + currentRoute.path,
                query: currentRoute.query
              })
            }
            break
          case 'refresh':
            bus.emit('refresh', resMsg.target)
            break
        }
      })
    },
    deleteHeaderDeal(count) {
      const list = this.headerDeal.gridData
      const index = list.indexOf(count)
      if (index > -1) {
        this.headerDeal.gridData.splice(index, 1)
      }
    },
  }
})

export const useGlobalStoreWithOut = () => {
  return useGlobalStore(store)
}

// export default fullSocket
