import { defineStore } from 'pinia'
import { store } from '../index'
import { CACHE_KEY, useCache } from '@/hooks/web/useCache'
const { wsCache } = useCache('sessionStorage')
import * as configApi from '@/api/infra/config'

export interface DictState {
  pages: number[]
  defaultPageSize: number
  skin: string
  sideTheme: string
  isSetPage: boolean
  config: object
}

export const useConfigStore = defineStore('config', {
  state: (): DictState => ({
    pages: [],
    defaultPageSize: 10,
    skin: '',
    sideTheme: '',
    config: {},
    isSetPage: false
  }),
  getters: {
    getPages(): number[] {
      const config = wsCache.get(CACHE_KEY.CONFIG)
      if (config && config.pages && config.pages.length) {
        this.pages = config.pages
      }
      return this.pages
    },
    getSkinName(): string {
      const config = wsCache.get(CACHE_KEY.CONFIG)
      if (config && config.skin) {
        switch (config.skin) {
          case 'skin-blue':
            this.skin = '#409eff'
            break
          case 'skin-yellow':
            this.skin = '#ff9800'
            break
          case 'skin-green':
            this.skin = '#009688'
            break
          case 'skin-sky-blue':
            this.skin = '#536dfe'
            break
          case 'skin-pink':
            this.skin = '#ff5c93'
            break
          case 'skin-orange':
            this.skin = '#ee4f12'
            break
          case 'skin-cyan':
            this.skin = '#0096c7'
            break
          case 'skin-purple':
            this.skin = '#9c27b0'
            break
        }
      }
      return this.skin
    },
    getSideTheme(): string {
      const config = wsCache.get(CACHE_KEY.CONFIG)
      if (config && config.sideTheme) {
        switch (config.sideTheme) {
          case 'theme-dark':
            this.sideTheme = '#001529'
            break
          case 'theme-light':
            this.sideTheme = '#fff'
            break
        }
      }
      return this.sideTheme
    },
    getIsSetPage(): boolean {
      return this.isSetPage
    },
    getPageSize(): number {
      const config = wsCache.get(CACHE_KEY.CONFIG)
      if (config && config.defaultPageSize) {
        this.defaultPageSize = config.defaultPageSize
      }
      return this.defaultPageSize
    }
  },
  actions: {
    async setConfig() {
      const config = wsCache.get(CACHE_KEY.CONFIG)
      if (config) {
        this.config = config
        this.isSetPage = true
      } else {
        const configData = {
          pages: [10, 20, 30, 50, 100],
          skin: '',
          sideTheme: '',
          defaultPageSize: 10
        }
        let dictDataMap = [10, 20, 30, 50, 100]
        try {
          const res = await configApi.getConfigListApi()
          if (res) {
            res.map((ite) => {
              // page分页
              if (ite.configKey == 'vxe.pagerConfig') {
                dictDataMap = ite.value.split(',')
                dictDataMap = dictDataMap.map(Number)
                // 设置数据
                this.pages = dictDataMap
                configData['pages'] = dictDataMap
              }
              if (ite.configKey == 'sys.index.skinName') {
                this.skin = ite.value
                configData['skin'] = ite.value
              }
              if (ite.configKey == 'sys.index.sideTheme') {
                this.sideTheme = ite.value
                configData['sideTheme'] = ite.value
              }
              if (ite.configKey == 'vxe.pagerConfig.defaultPageSize') {
                this.defaultPageSize = Number(ite.value)
                configData['defaultPageSize'] = Number(ite.value)
              }
            })
          }
        } catch (e) {
          console.log(e)
        }
        this.isSetPage = true
        wsCache.set(CACHE_KEY.CONFIG, configData, { exp: 60 }) // 60 秒 过期
      }
    },
    setDefaultPage(val) {
      this.defaultPageSize = val
      const configData = wsCache.get(CACHE_KEY.CONFIG)
      if (configData) {
        configData.defaultPageSize = val
        wsCache.set(CACHE_KEY.CONFIG, configData, { exp: 60 })
      } else {
        this.setConfig()
      }
    },
    setPageSizes(val) {
      this.pages = val
      const configData = wsCache.get(CACHE_KEY.CONFIG)
      if (configData) {
        configData.pages = val
        wsCache.set(CACHE_KEY.CONFIG, configData, { exp: 60 })
      } else {
        this.setConfig()
      }
    },
    resetState() {
      this.isSetPage = false
    }
  }
})

export const useConfigStoreWithOut = () => {
  return useConfigStore(store)
}
