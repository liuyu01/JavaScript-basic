<script lang="ts" name="EnvVar" setup>
import { DICT_TYPE, getIntDictOptions } from '@/utils/dict'
import bus from '@/utils/bus'
import { menuEnvVarStore } from '@/store/modules/menuEnvVar'
import { useTagsViewStore } from '@/store/modules/tagsView'
import { useCache } from '@/hooks/web/useCache'
const { wsCache } = useCache()
const envVarVal = ref(menuEnvVarStore().getMenuEnvVar)
const { push } = useRouter()
const changeEnvVar = (val) => {
  menuEnvVarStore().setMenuEnvVarAction(val);
  wsCache.set('menuEnvVar', val)
  bus.emit('changeEnvVar', val)
  useTagsViewStore().delAllViews()
  push('/')
}
onMounted(() => { 
  envVarVal.value =  envVarVal.value
})
</script>

<template>
  <el-select v-model="envVarVal" @change="changeEnvVar" style="width:105px;">
    <el-option
      v-for="dict in getIntDictOptions(DICT_TYPE.MENU_ENVVAR)"
      :key="dict.label"
      :label="dict.label"
      :value="dict.value"
    />
  </el-select>
</template>
