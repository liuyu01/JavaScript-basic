import './index.css'
import { useStore } from '../store'
import { observer } from 'mobx-react-lite'
import { useState } from 'react'
import uuid from 'react-uuid'

function Task () {
  // useStore
  const { taskStore } = useStore()
  // const store = useStore()
  // console.log(store)

  // 单选的受控
  // const [check,setCheck] = useState()
  // mobx Store去维护状态  input只需要把e.target.value交给store让他来进行修改
  function onChange (id, e) {
    console.log(e)
    // console.log(e.target.value)
    taskStore.singleCheck(id, e.target.checked)
  }
  // 全选
  function alickChange (e) {
    console.log(e)
    taskStore.allCheck(e.target.checked)
  }
  // 删除
  function delTask (id) {
    taskStore.delTask(id)
  }
  // 新增
  const [tackValue, setTaskValue] = useState('')
  function addTask (e) {
    if (e.keyCode === 13) {
      taskStore.addTask({
        id: uuid(),
        name: tackValue,
        idDone: false
      })
    }
    setTaskValue('')
  }
  return (
    <section className="todoapp">
      <header className="header">
        <h1>todos</h1>
        {/* 新增输入框 */}
        <input
          className="new-todo"
          autoFocus
          autoComplete="off"
          placeholder="What needs to be done?"
          value={tackValue}
          onChange={(e) => setTaskValue(e.target.value)}
          onKeyUp={addTask}
        />
      </header>
      <section className="main">
        {/* 全选 */}
        <input
          id="toggle-all"
          className="toggle-all"
          type="checkbox"
          checked={taskStore.isAll}
          onChange={alickChange}
        />
        <label htmlFor="toggle-all"></label>
        <ul className="todo-list">
          {/* completed类名标识 */}
          {taskStore.list.map(item => (
            // <li
            //   className='todo completed' key={item.id}
            // >
            <li
              className={item.isDone ? 'todo completed' : 'todo'} key={item.id}
            >
              <div className="view">
                {/* 单选框  受控和非受控   受控的方式 */}
                <input className="toggle"
                  type="checkbox"
                  checked={item.isDone}
                  onChange={(e) => onChange(item.id, e)}
                />
                {/* defaultChecked={item.isDone} */}
                <label >{item.name}</label>
                <button className="destroy" onClick={() => delTask(item.id)}></button>
              </div>
            </li>
          ))}
          {/* <li
            className="todo"
          >
            <div className="view">
              <input className="toggle" type="checkbox" />
              <label >learn react</label>
              <button className="destroy"></button>
            </div>
          </li> */}

        </ul>
      </section>
      <footer className='footer'>
        <span className='todo-count'>
          任务总数：{taskStore.list.length} 已完成：{taskStore.isFinishedLength}
        </span>
      </footer>
    </section>
  )
}

export default observer(Task)